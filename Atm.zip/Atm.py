from datetime import datetime

class ATM:
    def __init__(self, name, pin, balance=0):
        self.name = name
        self.pin = pin
        self.balance = balance
        self.history = []

    def check_balance(self):
        print("Balance: Rs.", self.balance)
        self.history.append("Balance Checked")

    def deposit(self):
        amount = float(input("Enter Deposit Amount: "))

        if amount > 0:
            self.balance = self.balance + amount
            self.history.append("Deposited Rs. " + str(amount))
            print("Money Deposited")
        else:
            print("Invalid Amount")

    def withdraw(self):
        amount = float(input("Enter Withdraw Amount: "))

        if amount <= self.balance:
            self.balance = self.balance - amount
            self.history.append("Withdrawn Rs. " + str(amount))
            print("Money Withdrawn")
        else:
            print("Insufficient Balance")

    def show_history(self):
        if len(self.history) == 0:
            print("No History")
        else:
            print("Transaction History:")
            for item in self.history:
                print(item)

    def receipt(self):
        print("\n----- ATM Receipt -----")
        print("Name:", self.name)
        print("Balance: Rs.", self.balance)
        print("Date & Time:", datetime.now())
        print("-------------------")


accounts = {}

accounts["Saad Ahmed"] = ATM("Saad Ahmed", "1234", 10000)


def create_account():
    name = input("Enter Name: ")

    if name in accounts:
        print("Account Already Exists")
        return

    pin = input("Create PIN: ")
    balance = float(input("Enter Balance: "))

    accounts[name] = ATM(name, pin, balance)

    print("Account Created")


def login():
    name = input("Enter Name: ")

    if name not in accounts:
        print("Account Not Found")
        return None

    pin = input("Enter PIN: ")

    if pin == accounts[name].pin:
        print("Login Successful")
        return accounts[name]
    else:
        print("Wrong PIN")
        return None


while True:
    print("\n===== ATM =====")
    print("1. Login")
    print("2. Create Account")
    print("3. Exit")

    option = input("Choose: ")

    if option == "1":
        user = login()

        if user:
            while True:
                print("\n----- MENU -----")
                print("1. Check Balance")
                print("2. Deposit")
                print("3. Withdraw")
                print("4. History")
                print("5. Receipt")
                print("6. Logout")

                choice = input("Choose: ")

                if choice == "1":
                    user.check_balance()

                elif choice == "2":
                    user.deposit()

                elif choice == "3":
                    user.withdraw()

                elif choice == "4":
                    user.show_history()

                elif choice == "5":
                    user.receipt()

                elif choice == "6":
                    print("Logged Out")
                    break

                else:
                    print("Invalid Choice")

    elif option == "2":
        create_account()

    elif option == "3":
        print("Thank You For Using ATM")
        break

    else:
        print("Invalid Option")